ALTER TABLE `#__categories` MODIFY `description` MEDIUMTEXT;
ALTER TABLE `#__session` MODIFY `data` MEDIUMTEXT;
ALTER TABLE `#__session` MODIFY `session_id` varchar(200);

